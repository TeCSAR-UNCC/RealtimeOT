
// Function prototypes
void usleep(unsigned int useconds);

void millisleep(unsigned int microseconds);

void sleep(unsigned int seconds);
